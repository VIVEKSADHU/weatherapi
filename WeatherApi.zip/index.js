const express = require("express");
const app = express();
const ejs = require("ejs");
const path = require("path");
const bodyParser = require("body-parser");
const axios = require("axios");

app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.get("/", (req, res) => {
  res.render("weather", { output: null, location: "" });
});

app.post("/", (req, res) => {
  const location = req.body.loc;
  const url = `http://api.weatherapi.com/v1/current.json?key=d4defb9dcdbf429190442131242007&q=${location}&aqi=no`;

  axios
    .get(url)
    .then((response) => {
      const output = response.data.current.temp_c;

      res.render("weather", { output: output, location: location });
    })
    .catch((error) => {
      console.error("Error fetching conversion rate:", error);
      res.render("weather", { output: "Error fetching location data" });
    });
});

app.listen("8080", () => {
  console.log("Server started on port 3000");
});
